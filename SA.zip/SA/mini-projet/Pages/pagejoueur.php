

<?php

is_connect();
/*
echo $_SESSION['user']['login']."<br>";
echo $_SESSION['user']['nom']."<br>";
echo $_SESSION['user']['prenom']."<br>";
echo $_SESSION['user']['profil']."<br>";
echo $_SESSION['user']['avatar']."<br>";

<a href="index.php?statut=logout">Deconnexion</a>

*/

?>


<div class="container-interface-joueur">
    <div class="header-joueur">
        <a href="index.php?statut=logout"><button type="button">Déconnexion</button></a>
        <div class="container-avatar">
            <img src="<?php echo $_SESSION['user']['avatar'] ?>" alt="">
            <div class="identite-joueur"><?php echo $_SESSION['user']['nom']."&nbsp;"; echo $_SESSION['user']['prenom']; ?></div>
        </div>
        <div class="header-text-joueur1">BIENVENUE SUR LA PLATEFORME DE JEU DE QUIZZ </div>
        <div class="header-text-joueur2">JOUER ET TESTER VOTRE NIVEAU DE CULTURE GÉNÉRALE</div>
    </div>
    <div class="body-joueur">
            <div class="quest-joueurs"></div>
            <div class="top-joueurs">
                <div class="menu-top">
                    <ul class="onglet">
                        <li><a href="index.php?page=jeux&onglet=otherscore" > Top Scores</a></li>
                        <li><a href="index.php?page=jeux&onglet=myscore" > Mon meilleur Score</a></li>
                    </ul>
                    </div>
                    <?php
                       if (isset($_GET['onglet']) && $_GET['onglet']=="otherscore") {
                            require_once("../Pages/otherscore.php");
                        }
                        elseif (isset($_GET['onglet']) && $_GET['onglet']=="myscore") {
                            require_once("../Pages/myscore.php"); 
                        }
                        
                        if (!isset($_GET['onglet'])) {
                            require_once("../Pages/otherscore.php");
                        }
                        

                            

                    ?>
                
                
            </div>
    </div>
</div>
<script type="text/javascript">
    const currentLocation = location.href;
    const menuItem = document.querySelectorAll('a');
    const menuLength = menuItem.length
    for (let i = 0; i < menu.length; i++) {
        if (menuItem[i].href === currentLocation ) {
            menuItem[i].className = "active"
        }
        
    }
</script>

