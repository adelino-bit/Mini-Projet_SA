


<div class="container-liste-question">

    <form action="" method="post">
        <div class="nbre-quest">
            <label for="">Nbre de question/Jeu</label>
            <input type="number" name="" id="" value="5">
            <button type="submit">ok</button>
        </div>
        <div class="container-question">
            <ol>
                <li>Les langages Web</li>
                    <input type="checkbox" name="" id=""><b>HTML</b><br>
                    <input type="checkbox" name="" id=""><b>R</b><br>
                    <input type="checkbox" name="" id=""><b>JAVA</b>
                <li>D’où vient le Corona?</li>
                    <input type="radio" name="" id=""><b>Italie</b><br>
                    <input type="radio" name="" id=""><b>Chine</b>
                <li>Quel terme définit langage qui s’adapte sur Androïd et sur Ios?</li>
                    <input type="text" name="" id="">
                <li>Quelle est la première école de codage gratuite au Sénégal?</li>
                    <input type="radio" name="" id=""><b>Simplon</b><br>
                    <input type="radio" name="" id=""><b>Orange Digital Center</b>
                <li>Les précurseurs de la révolution digitale</li>
                    <input type="radio" name="" id=""><b>GAFAM</b><br>
                    <input type="radio" name="" id=""><b>CIA-FBI</b>
            </ol>
        </div>
        <div class="question-suivant">
            <button type="submit">Suivant</button>
        </div>
        
    </form>
    

</div>