<?php

    $avatar='../Public/images/img5.jpg';    
    $message = "";
    if (isset($_POST['submit'])) {
      $prenom = ucfirst($_POST['prenom']);
      $nom = strtoupper($_POST['nom']);
      $login = $_POST['login'];
      $pwd1 = $_POST['pwd1'];
      $pwd2 = $_POST['pwd2'];

      $usernew=array();
      $usernew['nom']=$_POST['nom'];
      $usernew['prenom']=$_POST['prenom'];
      $usernew['login']=$_POST['login'];
      $usernew['password']=$_POST['pwd1'];
      $usernew['profile']="joueur";
      $usernew['Score']="";
     

      $avatar = $_FILES["file"]["name"];


      
        
        
      //On contrôle les mots de pass
      if ($pwd1 != $pwd2) {
        $message = "Les deux mots de passes ne sont pas identiques";

      }

      $user = file_get_contents('../Data/user.json');
      $user = json_decode($user, true);
      //On vérifie le login
        foreach ($user as $value) {
      
          if ($login == $value['login']) {
              $message = "Ce login existe déjà ";
            break;
            }
          } 
          $avatarPath = '../Public/images/'.basename($avatar); 
          $usernew['avatar']=$avatarPath;
          $user[]=$usernew;
          $user=json_encode($user);
          file_put_contents('../Data/user.json',$user);          // si le user à envoyer une photo     i

          if (!file_exists($_FILES['file']['tmp_name']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
            $avatar='../Public/images/img5.jpg';
            $usernew['avatar']= $avatar;

          }
          else{
              
              $avatarExtension = pathinfo($avatarPath,PATHINFO_EXTENSION);
              $avatarSize = $_FILES['file']['size'];
              //On contrôle les extensions
              if($avatarExtension != "jpg" && $avatarExtension != "jpeg" && $avatarExtension != "png"){

                $message = "Format Invalide";

              }
              //On contrôle la taille (elle ne doit pas dépasser  300Mo)
              if ($avatarSize > 314572800) {

                $message = "L'image dépasse les 300Mo maximal qui sont permises";
              }
              //On envoi l'image en testant l'upload (si true on envoi si false on affiche un message d'erreur)
              if(!move_uploaded_file($_FILES['file']['tmp_name'],$avatarPath)){

                 $message = "Erreur au niveau de l'envoi de l'image";

              }
      
            }
            if (!empty($avatar)&& empty($message)) {
                header("location:index.php");
            }
            
      
         
        
        

    }
    
    


?>





<div class="container-inscription1">
    <div class="container-inscription2">
        <div class="container-inscription3">
           <div class="container-inscription4">
                <div class="tittle1"><h2>S'INSCRIRE</h2></div>
               <div class="title2">Pour tester votre niveau de culture générale</div>
                <div class="trait"></div>
                <div class="img-joueur">
                    <div class="container-img-joueur"><img  class="container-img-joueur2"src="<?php echo $avatar ?>" alt="Votre image" id="photo_upload"  ></div>
                    <div class="legende-img">
                        <p>Avatar du joueur</p>
                    </div>
                </div>
                <div class="container-form-inscription">
                    <form action="" method="post" id="form-connexion" enctype="multipart/form-data">
                        <div class="champ">
                            <label for="">Prénom</label><br>
                            <input type="text" name="prenom" id="prenom" error="error-1" placeholder="Aaaa"><br><br><br>
                            <div class="erreur-form" id="error-1"></div>
                        </div>
                        <div class="champ">
                            <label for="">Nom</label><br>
                            <input type="text" name="nom" id="nom" error="error-2" placeholder="BBBB"><br><br><br>
                            <div class="erreur-form" id="error-2"></div>
                        </div>
                        <div class="champ">
                            <label for="">Login</label><br>
                            <input type="text" name="login" id="login" error="error-3" placeholder="aabaab"><br><br><br>
                            <div class="erreur-form" id="error-3"></div>
                        </div>
                        <div class="champ">
                            <label for="">Password</label><br>
                            <input type="password" name="pwd1" error="error-4" id="pwd1"><br><br><br>
                            <div class="erreur-form" id="error-4"></div>
                        </div>
                        <div class="champ">
                            <label for="">Confirmer Password</label><br>
                            <input type="password" name="pwd2" error="error-5"  id="pwd2"><br><br><br>
                            <div class="erreur-form" id="error-5"></div>
                        </div>
                        <div class="fichier">
                            <label for="">Avatar</label>
                           <button><input type="file" name="file" id="image" accept="image/*" onchange="loadFile(event)"></button>
                        </div>
                        <div class="button-submit">
                            <button type="submit" name="submit" id="submit">Créer Compte</button>
                        </div>
                        
                    </form><br><br><br><br><br><br>
                  
                        <?php if (! empty($message)) { ?>
                        <p class="Message"><?php echo $message; ?></p>
                        <?php } ?> 
                        
                </div>
               
           </div> 
        </div>
    </div>
</div>

<script src="../Public/js/quizz.js"></script>

<script>
  var loadFile = function(event) {
    var output = document.getElementById('photo_upload');
    output.src = URL.createObjectURL(event.target.files[0]);
    output.onload = function() {
      URL.revokeObjectURL(output.src)
    }
  };
</script>

