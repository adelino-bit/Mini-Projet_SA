<div class="container-liste-joueur">
    <div class="textlist"><h3><i>LISTE DES JOUEURS PAR SCORE</i></h3></div>
    <div class="listeparscore">
        <table>
            <tr class="tableau">
                <td>Nom</td>
                <td>Prenom</td>
                <td>Score</td>
            </tr>
            <tr>
                <?php

                        
                    $user = file_get_contents('../Data/user.json');
                    $user = json_decode($user, true);

                    foreach ($user as $value){
                        if ($value["profile"]==="joueur"){
                            $joueurs[] = $value;
                        }
                    }


                ?>

                <?php

                    for ($i=1; $i <15 ; $i++) { 
                        if (isset($joueurs[$i])){
                    

                ?>
                    <td><?php echo $joueurs[$i]['nom'] ?></td>
                    <td><?php echo $joueurs[$i]['prenom'] ?></td>
                    <td><?php echo $joueurs[$i]['Score'] ?></td>

                    

                <?php

                    }

                    if ($i%1==0) {
                        echo '</tr>';
                    }
                }
                

                ?>
                

            </tr>
            
        </table>



                        
                 
    </div>
    <button type="submit">Suivant</button>
</div>