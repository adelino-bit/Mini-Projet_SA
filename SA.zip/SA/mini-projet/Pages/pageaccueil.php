

<?php

is_connect();
/*
echo $_SESSION['user']['login']."<br>";
echo $_SESSION['user']['nom']."<br>";
echo $_SESSION['user']['prenom']."<br>";
echo $_SESSION['user']['profil']."<br>";
echo $_SESSION['user']['avatar']."<br>";

<a href="index.php?statut=logout">Deconnexion</a>


*/

?>

<div class="container-accueil">
    <div class="header-accueil">
        <a href="index.php?statut=logout"><button type="button">Déconnexion</button></a>
        <div class="header-text-accueil">CREER ET PARAMETRER VOS QUIZZ</div>
    </div>
    <div class="zone-commun">

    
<?php

if (isset($_GET['menu']) && $_GET['menu']=="creer-question") {
    require_once("../Pages/creerquestion.php");
}
elseif (isset($_GET['menu']) && $_GET['menu']=="creer-admin") {
    require_once("../Pages/creeradmin.php"); 
}
elseif(isset($_GET['menu']) && $_GET['menu']=="liste-joueurs"){
    require_once("../Pages/listejoueur.php");

}
else {

    require_once("../Pages/listequestions.php");
}





?>




    </div>
    <div class="menu">
        <div class="menu-header">
            <div class="menu-cercle"><img src="<?php echo $_SESSION['user']['avatar'] ?>" alt="photo de l'administarteur"></div>
            <div class="identite-admin"><?php echo $_SESSION['user']['nom']."<br>"; echo $_SESSION['user']['prenom']."<br>"; ?></div>
        </div>
        <div class="tache-admin">
            <div class="menu-tache"><a href="index.php?page=accueil&menu=liste-question">Liste Question</a><img src="../Public/icones/ic-liste-active.png" alt="icone liste question"></div>
            <div class="menu-tache"><a href="index.php?page=accueil&menu=creer-admin">Créer Admin</a><img src="../Public/icones/ic-ajout.png" alt="icone ajout"></div>
            <div class="menu-tache"><a href="index.php?page=accueil&menu=liste-joueurs">Liste joueurs</a><img src="../Public/icones/ic-liste.png" alt="icone liste joueurs"></div>
            <div class="menu-tache"><a href="index.php?page=accueil&menu=creer-questions">Créer Questions</a><img src="../Public/icones/ic-ajout.png" alt="icone ajout"></div>
            
        </div>
               
    </div>
    
</div>
