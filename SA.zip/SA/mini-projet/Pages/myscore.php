<div class="container-myscore">
    <div class="monscore"><p>Mon score: &nbsp <?php echo $_SESSION['Score'] ?> &nbsp pts </p></div>
</div>